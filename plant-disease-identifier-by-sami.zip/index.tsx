/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// --- DOM Element Selection ---
const videoContainer = document.getElementById('video-container') as HTMLDivElement;
const videoElement = document.getElementById('video-element') as HTMLVideoElement;
const previewContainer = document.getElementById('preview-container') as HTMLDivElement;
const imagePreview = document.getElementById('image-preview') as HTMLImageElement;

const fileInput = document.getElementById('file-input') as HTMLInputElement;
const cameraBtn = document.getElementById('camera-btn') as HTMLButtonElement;
const captureBtn = document.getElementById('capture-btn') as HTMLButtonElement;
const clearBtn = document.getElementById('clear-btn') as HTMLButtonElement;
const diagnoseBtn = document.getElementById('diagnose-btn') as HTMLButtonElement;
const inputOptions = document.getElementById('input-options') as HTMLDivElement;

const loader = document.getElementById('loader') as HTMLDivElement;
const resultsContent = document.getElementById('results-content') as HTMLDivElement;
const errorMessage = document.getElementById('error-message') as HTMLDivElement;

let currentImageBase64: string | null = null;
let stream: MediaStream | null = null;

// --- State Management ---
function showElement(el: HTMLElement, show: boolean) {
  el.style.display = show ? 'block' : 'none';
}

function setUIState(state: 'initial' | 'capturing' | 'preview' | 'loading' | 'results') {
  showElement(inputOptions, state === 'initial');
  showElement(videoContainer, state === 'capturing');
  showElement(previewContainer, state === 'preview' || state === 'loading' || state === 'results');
  showElement(diagnoseBtn, state === 'preview' || state === 'results');
  showElement(loader, state === 'loading');
  
  diagnoseBtn.disabled = state !== 'preview' && state !== 'results';

  if (state === 'initial') {
    currentImageBase64 = null;
    imagePreview.src = '';
    resultsContent.innerHTML = '';
    errorMessage.innerHTML = '';
  }
}

// --- File & Camera Handling ---
async function fileToGenerativePart(file: File) {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
}

const handleFileSelect = async (event: Event) => {
  const target = event.target as HTMLInputElement;
  const file = target.files?.[0];
  if (!file) return;

  try {
    const part = await fileToGenerativePart(file);
    currentImageBase64 = part.inlineData.data;
    imagePreview.src = `data:${part.inlineData.mimeType};base64,${currentImageBase64}`;
    setUIState('preview');
  } catch (e) {
    console.error(e);
    handleError('Could not process the selected file.');
  }
};

const startCamera = async () => {
  try {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    videoElement.srcObject = stream;
    setUIState('capturing');
  } catch (error) {
    console.error('Error accessing camera:', error);
    handleError('Could not access the camera. Please ensure permissions are granted.');
    setUIState('initial');
  }
};

const captureImage = () => {
  const canvas = document.createElement('canvas');
  canvas.width = videoElement.videoWidth;
  canvas.height = videoElement.videoHeight;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);
  const dataUrl = canvas.toDataURL('image/jpeg');
  currentImageBase64 = dataUrl.split(',')[1];
  imagePreview.src = dataUrl;

  stopCamera();
  setUIState('preview');
};

const stopCamera = () => {
  if (stream) {
    stream.getTracks().forEach(track => track.stop());
    stream = null;
  }
  videoElement.srcObject = null;
};

const clearPreview = () => {
  stopCamera();
  fileInput.value = ''; // Reset file input
  setUIState('initial');
};


// --- Gemini API Interaction ---
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const diagnosePlant = async () => {
  if (!currentImageBase64) {
    handleError('No image selected for diagnosis.');
    return;
  }

  setUIState('loading');
  resultsContent.innerHTML = '';
  errorMessage.innerHTML = '';

  try {
    const imagePart = {
        inlineData: {
          mimeType: 'image/jpeg', // We convert to jpeg from camera
          data: currentImageBase64,
        },
    };

    const textPart = {
        text: "You are an expert botanist and plant pathologist. Identify the plant and any disease shown in this image. If a disease is present, provide its common name, a detailed description, potential causes, and suggest both organic and chemical treatment options. If the plant appears healthy, state that. If the image is not a plant, say so. Format your response clearly with headings for each section."
    };

    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] },
    });

    const text = response.text;
    resultsContent.innerHTML = text.replace(/\n/g, '<br>'); // Simple formatting
    setUIState('results');

  } catch (error) {
    console.error(error);
    handleError('An error occurred while communicating with the AI. Please try again.');
    setUIState('preview');
  } finally {
      showElement(loader, false);
  }
};

function handleError(message: string) {
  errorMessage.textContent = message;
}

// --- Event Listeners ---
fileInput.addEventListener('change', handleFileSelect);
cameraBtn.addEventListener('click', startCamera);
captureBtn.addEventListener('click', captureImage);
clearBtn.addEventListener('click', clearPreview);
diagnoseBtn.addEventListener('click', diagnosePlant);

// --- Initial Setup ---
setUIState('initial');
